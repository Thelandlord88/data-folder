#!/usr/bin/env node
/**
 * NEXUS Runtime v2.0 - Strategic Intelligence Runtime Server (TypeScript)
 * 
 * Complete TypeScript rewrite of NEXUS runtime using:
 * - NEXUS.engine.v2.ts (unified trait composition)
 * - PersonalityRegistryLoader.ts (circuit breaker, caching)
 * - Full type safety and production features
 * 
 * Endpoints:
 * - GET /status - System status and health
 * - POST /enhance - Main personality enhancement
 * - POST /breakthrough - Report breakthrough moments
 * - POST /reload-consciousness - Hot reload patterns
 * - WebSocket /ws - Live updates
 */

import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { readFile, writeFile } from 'node:fs/promises';

import { PersonalityRegistryLoader } from './loaders/PersonalityRegistryLoader.js';
import { TraitCompositionBridge, MultiPersonalityResponseGenerator } from './NEXUS.engine.v2.js';
import type { PersonalityData } from './types/personality.types.js';

// For ESM __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

/**
 * Enhancement history event
 */
interface HistoryEvent {
  timestamp: string;
  personality: string;
  patternsApplied: string[];
  request: string;
  summary: string;
  guidance: string;
}

/**
 * Breakthrough moment
 */
interface BreakthroughMoment {
  timestamp: string;
  trigger: string;
  insight: string;
  context: string;
  significance: string;
}

/**
 * Consciousness patterns
 */
interface ConsciousnessPatterns {
  problemDecomposition?: any;
  systemsThinking?: any;
  workflowEfficiency?: any;
  breakthroughMoments?: any;
}

/**
 * NEXUS Runtime Server
 */
class NexusRuntime {
  private server: any;
  private wss: WebSocketServer | null = null;
  private personalityLoader: PersonalityRegistryLoader;
  private traitBridge: TraitCompositionBridge;
  
  private initialized = false;
  private startTime = Date.now();
  private enhancementsPerformed = 0;
  private historyEvents: HistoryEvent[] = [];
  private breakthroughMoments: BreakthroughMoment[] = [];
  private consciousness: Record<string, any> = {};
  private wsClients = new Set<WebSocket>();
  
  // Rate limiting
  private requestCounts = new Map<string, { count: number; resetTime: number }>();
  private readonly RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
  private readonly RATE_LIMIT_MAX_REQUESTS = 30; // 30 requests per minute per IP

  constructor() {
    this.personalityLoader = new PersonalityRegistryLoader();
    this.traitBridge = new TraitCompositionBridge();
    this.server = createServer(this.handleRequest.bind(this));
  }

  /**
   * Initialize NEXUS consciousness and personality system
   */
  async initialize(isReload = false): Promise<void> {
    try {
      console.log(isReload ? '🔄 Reloading NEXUS consciousness...' : '🧠 Initializing NEXUS consciousness...');
      
      // Load consciousness patterns
      await this.loadConsciousnessPatterns();
      
      // Initialize personality registry
      if (!isReload) {
        await this.personalityLoader.initialize();
      }
      
      // Initialize trait composition bridge
      const registry = this.personalityLoader.getPersonalityRegistry();
      await this.traitBridge.initialize(registry);
      
      // Load history from disk
      if (!isReload) {
        await this.loadHistoryFromDisk();
      }
      
      this.initialized = true;
      console.log('✅ NEXUS consciousness and trait composition loaded');
      
    } catch (error) {
      console.warn('⚠️ NEXUS consciousness initialization failed:', (error as Error).message);
      this.consciousness = {
        problemDecomposition: null,
        systemsThinking: null,
        workflowEfficiency: null,
        breakthroughMoments: null
      };
    }
  }

  /**
   * Load consciousness patterns from disk
   */
  private async loadConsciousnessPatterns(): Promise<void> {
    const patterns = ['problem-decomposition', 'systems-thinking', 'workflow-efficiency', 'breakthrough-moments'];
    let loadedCount = 0;

    this.consciousness = {
      problemDecomposition: null,
      systemsThinking: null,
      workflowEfficiency: null,
      breakthroughMoments: null
    };

    for (const patternName of patterns) {
      try {
        const filePath = resolve(__dirname, `./consciousness/${patternName}.json`);
        const content = await readFile(filePath, 'utf-8');
        const data = JSON.parse(content);

        // Map pattern names to consciousness properties
        const key = patternName.replace(/-([a-z])/g, (_, letter) => letter.toUpperCase()) as keyof ConsciousnessPatterns;
        (this.consciousness as any)[key] = data;
        loadedCount++;
      } catch (error) {
        console.warn(`⚠️ Could not load ${patternName}:`, (error as Error).message);
      }
    }

    console.log(`✅ NEXUS consciousness initialized (${loadedCount}/4 patterns loaded)`);
  }

  /**
   * Load history from disk
   */
  private async loadHistoryFromDisk(): Promise<void> {
    try {
      const historyPath = resolve(__dirname, './consciousness/enhancement-history.json');
      const content = await readFile(historyPath, 'utf-8');
      const data = JSON.parse(content);
      
      if (data.events && Array.isArray(data.events)) {
        this.historyEvents = data.events;
        console.log(`📜 Loaded ${this.historyEvents.length} history events from disk`);
      }
    } catch (error) {
      // File doesn't exist yet, that's ok
    }
  }

  /**
   * Save history to disk
   */
  private async saveHistoryToDisk(): Promise<void> {
    try {
      const historyPath = resolve(__dirname, './consciousness/enhancement-history.json');
      const data = {
        events: this.historyEvents.slice(-100), // Keep last 100 events
        lastUpdated: new Date().toISOString()
      };
      
      await writeFile(historyPath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (error) {
      console.warn('⚠️ Could not save history:', (error as Error).message);
    }
  }

  /**
   * Start the runtime server
   */
  async start(port = 8080): Promise<void> {
    await this.initialize();

    const server = createServer((req, res) => this.handleRequest(req, res));
    
    // WebSocket server
    const wss = new WebSocketServer({ server, path: '/ws' });
    wss.on('connection', (ws) => this.handleWebSocketConnection(ws));

    server.listen(port, '0.0.0.0', () => {
      console.log(`🌐 NEXUS Runtime listening on http://127.0.0.1:${port}`);
    });

    // Periodic history save
    setInterval(() => {
      if (this.historyEvents.length > 0) {
        this.saveHistoryToDisk();
      }
    }, 10000); // Every 10 seconds
  }

  /**
   * Handle HTTP requests
   */
  private async handleRequest(req: IncomingMessage, res: ServerResponse): Promise<void> {
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    try {
      // GET /status
      if (req.method === 'GET' && req.url === '/status') {
        await this.handleStatus(req, res);
        return;
      }

      // POST /enhance
      if (req.method === 'POST' && req.url === '/enhance') {
        await this.handleEnhance(req, res);
        return;
      }

      // POST /breakthrough
      if (req.method === 'POST' && req.url === '/breakthrough') {
        await this.handleBreakthrough(req, res);
        return;
      }

      // POST /reload-consciousness
      if (req.method === 'POST' && req.url === '/reload-consciousness') {
        await this.handleReloadConsciousness(req, res);
        return;
      }

      // 404
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not Found');
      
    } catch (error) {
      console.error('Error handling request:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Internal Server Error' }));
    }
  }

  /**
   * Handle /status endpoint
   */
  private async handleStatus(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const uptimeMs = Date.now() - this.startTime;
    const registry = this.personalityLoader.getPersonalityRegistry();
    const health = await this.personalityLoader.healthCheck();
    const analytics = this.traitBridge.getCompositionAnalytics();

    const status = {
      initialized: this.initialized,
      uptime: this.formatUptime(uptimeMs),
      uptimeMs,
      port: 8080,
      version: '2.0.0',
      engine: 'NEXUS.engine.v2.ts (TypeScript)',
      
      consciousnessHealth: this.calculateConsciousnessHealth(),
      
      loaderHealth: {
        status: health.status,
        circuitBreakerState: health.details.circuitBreakerState,
        memoryUsageMB: health.details.memoryUsageMB
      },
      
      personalitySystem: {
        totalPersonalities: registry.size,
        circuitBreakerState: health.details.circuitBreakerState,
        cacheEnabled: health.details.cacheEnabled,
        cacheHitRate: health.details.cacheStats?.hitRate || 0
      },
      
      traitComposition: analytics,
      
      patternsLoaded: this.countPatternsLoaded(),
      consciousness: this.listLoadedPatterns(),
      
      enhancementsPerformed: this.enhancementsPerformed,
      recentEvents: this.historyEvents.slice(-5),
      breakthroughMoments: this.breakthroughMoments.length > 0 ? this.breakthroughMoments.slice(-3) : null,
      
      systemHealth: {
        ...health,
        historyBufferSize: this.historyEvents.length,
        wsConnections: this.wsClients.size
      }
    };

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(status, null, 2));
  }

  /**
   * Handle /enhance endpoint
   * IMPROVED: Added rate limiting
   */
  private async handleEnhance(req: IncomingMessage, res: ServerResponse): Promise<void> {
    // Check rate limit
    const clientIp = req.socket.remoteAddress || 'unknown';
    if (!this.checkRateLimit(clientIp, res)) {
      return;
    }

    const body = await this.readBody(req);
    
    // Validate request
    if (!this.validateRequest(body, res)) {
      return;
    }

    const { personalityName, request, mode = 'AUTO' } = body;

    try {
      let response: any;
      let actualPersonalityName = personalityName;

      // AUTO mode - select optimal personality
      if (mode === 'AUTO' && !personalityName) {
        actualPersonalityName = await this.traitBridge.selectOptimalPersonality(request);
      }

      // COMPOSE mode - multi-personality composition
      if (mode === 'COMPOSE') {
        const composedAgent = await this.traitBridge.composeOptimalAgent(request, 5);
        const registry = this.personalityLoader.getPersonalityRegistry();
        const generator = new MultiPersonalityResponseGenerator(composedAgent, registry);
        response = await generator.generateResponse(request);
      } else {
        // Single personality mode
        const personality = this.personalityLoader.getPersonality(actualPersonalityName);
        
        if (!personality) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: `Personality '${actualPersonalityName}' not found` }));
          return;
        }

        response = this.generatePersonalityResponse(actualPersonalityName, personality, request);
      }

      this.enhancementsPerformed++;
      
      // Record in history
      this.recordEnhancement({
        timestamp: new Date().toISOString(),
        personality: response.personalityUsed || actualPersonalityName,
        patternsApplied: response.traitApplications || [],
        request,
        summary: request,
        guidance: response.content
      });

      // Check for breakthrough
      this.checkForBreakthrough(request, response.content);

      // Broadcast to WebSocket clients
      this.broadcastToClients({
        type: 'enhancement',
        personality: response.personalityUsed || actualPersonalityName,
        timestamp: new Date().toISOString()
      });

      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, response }));

    } catch (error) {
      console.error('Enhancement error:', error);
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: (error as Error).message }));
    }
  }

  /**
   * Handle /breakthrough endpoint
   */
  private async handleBreakthrough(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = await this.readBody(req);
    
    if (!body.trigger || !body.insight) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Missing required fields: trigger, insight' }));
      return;
    }

    const breakthrough: BreakthroughMoment = {
      timestamp: new Date().toISOString(),
      trigger: body.trigger,
      insight: body.insight,
      context: body.context || '',
      significance: body.significance || 'medium'
    };

    this.breakthroughMoments.push(breakthrough);
    
    this.broadcastToClients({
      type: 'breakthrough',
      breakthrough,
      timestamp: new Date().toISOString()
    });

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true, breakthrough }));
  }

  /**
   * Handle /reload-consciousness endpoint
   */
  private async handleReloadConsciousness(req: IncomingMessage, res: ServerResponse): Promise<void> {
    const body = await this.readBody(req);
    
    if (!this.validateContentType(req, res)) {
      return;
    }

    try {
      await this.loadConsciousnessPatterns();
      
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        success: true,
        message: 'Consciousness patterns reloaded successfully',
        patternsLoaded: this.countPatternsLoaded(),
        timestamp: new Date().toISOString()
      }));
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: (error as Error).message }));
    }
  }

  /**
   * Handle WebSocket connections
   */
  private handleWebSocketConnection(ws: WebSocket): void {
    this.wsClients.add(ws);
    console.log(`📡 WebSocket client connected (${this.wsClients.size} total)`);

    ws.on('close', () => {
      this.wsClients.delete(ws);
      console.log(`📡 WebSocket client disconnected (${this.wsClients.size} remaining)`);
    });

    // Send welcome message
    ws.send(JSON.stringify({
      type: 'welcome',
      message: 'Connected to NEXUS Runtime v2.0',
      timestamp: new Date().toISOString()
    }));
  }

  /**
   * Broadcast message to all WebSocket clients
   */
  private broadcastToClients(message: any): void {
    const data = JSON.stringify(message);
    for (const client of this.wsClients) {
      if (client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    }
  }

  /**
   * Generate personality response (fallback for single personality)
   */
  private generatePersonalityResponse(name: string, personality: PersonalityData, request: string): any {
    const traits = Object.values(personality.cognitiveTraits || {});
    
    return {
      content: `### 🧠 ${personality.identity.name} Response\n\n` +
               `**Request**: ${request}\n\n` +
               `**Traits**: ${traits.map(t => t.name).join(', ')}\n\n` +
               `**Analysis**: This response applies ${personality.identity.name}'s cognitive capabilities.\n`,
      personalityUsed: personality.identity.name,
      traitApplications: traits.map(t => t.name),
      confidenceScore: 0.8,
      nexusEnhanced: true
    };
  }

  /**
   * Record enhancement in history
   */
  private recordEnhancement(event: HistoryEvent): void {
    this.historyEvents.push(event);
    
    // Keep last 100 events in memory
    if (this.historyEvents.length > 100) {
      this.historyEvents = this.historyEvents.slice(-100);
    }
  }

  /**
   * Check for breakthrough moment
   */
  private checkForBreakthrough(request: string, response: string): void {
    const breakthroughTriggers = ['WAIT. WAIT.', 'breakthrough', 'discovery', 'insight'];
    const requestLower = request.toLowerCase();
    const responseLower = response.toLowerCase();

    for (const trigger of breakthroughTriggers) {
      if (requestLower.includes(trigger.toLowerCase()) || responseLower.includes(trigger.toLowerCase())) {
        const breakthrough: BreakthroughMoment = {
          timestamp: new Date().toISOString(),
          trigger,
          insight: request.substring(0, 200),
          context: 'Auto-detected from enhancement',
          significance: 'medium'
        };
        
        this.breakthroughMoments.push(breakthrough);
        console.log('💡 Breakthrough detected:', trigger);
        break;
      }
    }
  }

  /**
   * Calculate consciousness health score
   */
  private calculateConsciousnessHealth() {
    const patternsHealthy = this.countPatternsLoaded() >= 4;
    const bridgeHealthy = this.initialized;
    const historyActive = this.historyEvents.length > 0;
    const breakthroughCapture = this.breakthroughMoments.length > 0;

    const healthFactors = [patternsHealthy, bridgeHealthy, historyActive, breakthroughCapture];
    const healthScore = healthFactors.filter(Boolean).length / healthFactors.length;

    let status = 'critical';
    if (healthScore >= 0.9) status = 'optimal';
    else if (healthScore >= 0.7) status = 'good';
    else if (healthScore >= 0.5) status = 'fair';

    return {
      score: Math.round(healthScore * 100),
      status,
      factors: {
        patternsLoaded: patternsHealthy,
        bridgeInitialized: bridgeHealthy,
        historyActive,
        breakthroughCapture
      }
    };
  }

  /**
   * Utility functions
   */
  private async readBody(req: IncomingMessage): Promise<any> {
    return new Promise((resolve, reject) => {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', () => {
        try {
          resolve(body ? JSON.parse(body) : {});
        } catch (error) {
          reject(new Error('Invalid JSON'));
        }
      });
    });
  }

  /**
   * Validate and sanitize request body
   * IMPROVED: Better validation with length checks and sanitization
   */
  private validateRequest(body: any, res: ServerResponse): boolean {
    // Check if request field exists
    if (!body.request) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Missing required field: request' }));
      return false;
    }

    // Check if request is a string
    if (typeof body.request !== 'string') {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Field "request" must be a string' }));
      return false;
    }

    // Check if request is empty or only whitespace
    if (body.request.trim().length === 0) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Request cannot be empty' }));
      return false;
    }

    // Check maximum length (10KB)
    if (body.request.length > 10000) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Request too long (max 10000 characters)' }));
      return false;
    }

    // Validate mode if provided
    if (body.mode && !['AUTO', 'COMPOSE'].includes(body.mode)) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Mode must be "AUTO" or "COMPOSE"' }));
      return false;
    }

    // Sanitize request (trim whitespace)
    body.request = body.request.trim();

    return true;
  }

  /**
   * Check rate limit for client IP
   * IMPROVED: Simple rate limiting to prevent abuse
   */
  private checkRateLimit(clientIp: string, res: ServerResponse): boolean {
    const now = Date.now();
    const clientData = this.requestCounts.get(clientIp);

    if (!clientData || now > clientData.resetTime) {
      // New window or expired - reset counter
      this.requestCounts.set(clientIp, {
        count: 1,
        resetTime: now + this.RATE_LIMIT_WINDOW_MS
      });
      return true;
    }

    // Increment counter
    clientData.count++;

    // Check if over limit
    if (clientData.count > this.RATE_LIMIT_MAX_REQUESTS) {
      const retryAfter = Math.ceil((clientData.resetTime - now) / 1000);
      res.writeHead(429, {
        'Content-Type': 'application/json',
        'Retry-After': retryAfter.toString()
      });
      res.end(JSON.stringify({
        error: 'Rate limit exceeded',
        message: `Too many requests. Please try again in ${retryAfter} seconds.`,
        retryAfter
      }));
      return false;
    }

    return true;
  }

  private validateContentType(req: IncomingMessage, res: ServerResponse): boolean {
    const contentType = req.headers['content-type'];
    if (!contentType || !contentType.includes('application/json')) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Content-Type must be application/json' }));
      return false;
    }
    return true;
  }

  private countPatternsLoaded(): number {
    if (!this.consciousness) return 0;
    return Object.values(this.consciousness).filter(p => p !== null).length;
  }

  private listLoadedPatterns(): string[] {
    if (!this.consciousness) return [];
    const patterns: string[] = [];
    for (const [key, value] of Object.entries(this.consciousness)) {
      if (value !== null) {
        patterns.push(key);
      }
    }
    return patterns;
  }

  private formatUptime(uptimeMs: number): string {
    const seconds = Math.floor(uptimeMs / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ${hours % 24}h`;
    if (hours > 0) return `${hours}h ${minutes % 60}m`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
    return `${seconds}s`;
  }
}

// Start the server
const runtime = new NexusRuntime();
runtime.start(8080).catch(console.error);
