# NEXUS v3 Package Manifest

**Package Date**: Tue Oct  7 23:40:48 UTC 2025
**Version**: 3.0.0
**Package Name**: nexus-v3-complete

## Contents

### Source Files (src/)
5 TypeScript files

### Compiled Files (dist/)
26 JavaScript files

### Personality Profiles (profiles/)
45 JSON profiles

### Documentation (docs/)
13 Markdown files

## File Listing

```
./INSTALL.md
./MANIFEST.md
./README.md
./consciousness/enhancement-history.json
./dist/Hunter.audit.d.ts
./dist/Hunter.audit.d.ts.map
./dist/Hunter.audit.js
./dist/Hunter.audit.js.map
./dist/Hunter.auditAgent.d.ts
./dist/Hunter.auditAgent.d.ts.map
./dist/Hunter.auditAgent.js
./dist/Hunter.auditAgent.js.map
./dist/Hunter.policy.d.ts
./dist/Hunter.policy.d.ts.map
./dist/Hunter.policy.js
./dist/Hunter.policy.js.map
./dist/NEXUS.engine.d.ts
./dist/NEXUS.engine.d.ts.map
./dist/NEXUS.engine.js
./dist/NEXUS.engine.js.map
./dist/NEXUS.engine.v2.d.ts
./dist/NEXUS.engine.v2.d.ts.map
./dist/NEXUS.engine.v2.js
./dist/NEXUS.engine.v2.js.map
./dist/NEXUS.integration.d.ts
./dist/NEXUS.integration.d.ts.map
./dist/NEXUS.integration.js
./dist/NEXUS.integration.js.map
./dist/architect-designs-hunter.d.ts
./dist/architect-designs-hunter.d.ts.map
./dist/architect-designs-hunter.js
./dist/architect-designs-hunter.js.map
./dist/consciousness/breakthrough-moments.json
./dist/consciousness/enhancement-history.json
./dist/consciousness/pattern-evolution-engine.json
./dist/consciousness/problem-decomposition.json
./dist/consciousness/systems-thinking.json
./dist/consciousness/workflow-efficiency.json
./dist/demo-personality-loader.d.ts
./dist/demo-personality-loader.d.ts.map
./dist/demo-personality-loader.js
./dist/demo-personality-loader.js.map
./dist/fs-utils.d.ts
./dist/fs-utils.d.ts.map
./dist/fs-utils.js
./dist/fs-utils.js.map
./dist/guardian-orchestrator.d.ts
./dist/guardian-orchestrator.d.ts.map
./dist/guardian-orchestrator.js
./dist/guardian-orchestrator.js.map
./dist/loaders/PersonalityRegistryLoader.d.ts
./dist/loaders/PersonalityRegistryLoader.d.ts.map
./dist/loaders/PersonalityRegistryLoader.js
./dist/loaders/PersonalityRegistryLoader.js.map
./dist/nexus-bridge.d.ts
./dist/nexus-bridge.d.ts.map
./dist/nexus-bridge.js
./dist/nexus-bridge.js.map
./dist/nexus-integration.d.ts
./dist/nexus-integration.d.ts.map
./dist/nexus-integration.js
./dist/nexus-integration.js.map
./dist/nexus-runtime.d.ts
./dist/nexus-runtime.d.ts.map
./dist/nexus-runtime.js
./dist/nexus-runtime.js.map
./dist/nexus-runtime.v2.d.ts
./dist/nexus-runtime.v2.d.ts.map
./dist/nexus-runtime.v2.js
./dist/nexus-runtime.v2.js.map
./dist/nexus-trait-bridge.d.ts
./dist/nexus-trait-bridge.d.ts.map
./dist/nexus-trait-bridge.js
./dist/nexus-trait-bridge.js.map
./dist/personality-architect-integration-test.d.ts
./dist/personality-architect-integration-test.d.ts.map
./dist/personality-architect-integration-test.js
./dist/personality-architect-integration-test.js.map
./dist/response-generators/DaedalusResponseGenerator.d.ts
./dist/response-generators/DaedalusResponseGenerator.d.ts.map
./dist/response-generators/DaedalusResponseGenerator.js
./dist/response-generators/DaedalusResponseGenerator.js.map
./dist/response-generators/HunterResponseGenerator.d.ts
./dist/response-generators/HunterResponseGenerator.d.ts.map
./dist/response-generators/HunterResponseGenerator.js
./dist/response-generators/HunterResponseGenerator.js.map
./dist/response-generators/ResponseGenerator.interface.d.ts
./dist/response-generators/ResponseGenerator.interface.d.ts.map
./dist/response-generators/ResponseGenerator.interface.js
./dist/response-generators/ResponseGenerator.interface.js.map
./dist/response-generators/ResponseGeneratorFactory.d.ts
./dist/response-generators/ResponseGeneratorFactory.d.ts.map
./dist/response-generators/ResponseGeneratorFactory.js
./dist/response-generators/ResponseGeneratorFactory.js.map
./dist/run-hunter-audit.d.ts
./dist/run-hunter-audit.d.ts.map
./dist/run-hunter-audit.js
./dist/run-hunter-audit.js.map
./dist/systemic-scanner.d.ts
./dist/systemic-scanner.d.ts.map
./dist/systemic-scanner.js
./dist/systemic-scanner.js.map
./dist/types.d.ts
./dist/types.d.ts.map
./dist/types.js
./dist/types.js.map
./dist/types/personality.types.d.ts
./dist/types/personality.types.d.ts.map
./dist/types/personality.types.js
./dist/types/personality.types.js.map
./dist/validation/personality-schema.d.ts
./dist/validation/personality-schema.d.ts.map
./dist/validation/personality-schema.js
./dist/validation/personality-schema.js.map
./docs/18_PERSONALITIES_INSTALLATION_COMPLETE.md
./docs/COMPREHENSIVE_REPORT.md
./docs/ENHANCEMENT_HISTORY_STATUS.md
./docs/INDEX.md
./docs/MANIFEST.md
./docs/NEXUS2_README.md
./docs/NEXUS_BRAIN_INVESTIGATION.md
./docs/NEXUS_EXECUTIVE_SUMMARY.md
./docs/NEXUS_INITIAL_FINDINGS.md
./docs/NEXUS_PHASE1_COMPLETE.md
./docs/NEXUS_PHASE2_COMPLETE.md
./docs/NEXUS_PHASE3_COMPLETE.md
./docs/README.md
./package.json
./profiles/aria.json
./profiles/artdirector.json
./profiles/atlas-geo.json
./profiles/atlas.json
./profiles/chainarchitect.json
./profiles/chorus.json
./profiles/chromatic.json
./profiles/cipher.json
./profiles/codex-liaison.json
./profiles/contextweaver.json
./profiles/daedalus.json
./profiles/datawhisperer.json
./profiles/ethicsguard.json
./profiles/finetuner.json
./profiles/flash.json
./profiles/forge.json
./profiles/guardian.json
./profiles/hunter.json
./profiles/integrationmaestro.json
./profiles/localize.json
./profiles/manifest.json
./profiles/muse.json
./profiles/narrative.json
./profiles/nexus-api.json
./profiles/performancehawk.json
./profiles/personality-architect.json
./profiles/photorealist.json
./profiles/promptcrafter.json
./profiles/promptsmith.json
./profiles/property-sage.json
./profiles/pulse.json
./profiles/pulsewriter.json
./profiles/pythonista.json
./profiles/quantumlogic.json
./profiles/route-master.json
./profiles/sage.json
./profiles/scribe.json
./profiles/stellar.json
./profiles/styleforge.json
./profiles/symphony.json
./profiles/tokenmaster.json
./profiles/touch.json
./profiles/visionary.json
./profiles/visualarchitect.json
./profiles/wordsmith.json
./src/NEXUS.engine.v2.ts
./src/loaders/PersonalityRegistryLoader.ts
./src/nexus-runtime.v2.ts
./src/types/personality.types.ts
./src/validation/personality-schema.ts
./tsconfig.json
./verify-circuit-breaker.mjs
```

## Package Size

2.0M

## Checksums

```
02efeb7124ece5dcaa4ccd5fb0b376e5  ./profiles/pulsewriter.json
05a6e06544f56001473be2e240aad99c  ./dist/systemic-scanner.d.ts
0713b64d4babc95e39831dd8d68ba1ce  ./dist/guardian-orchestrator.js.map
0856aff24843412cd60ecdf38dde0df0  ./profiles/stellar.json
0b7dfc3dbfb1b8043e1489304657c457  ./profiles/guardian.json
0bed8620d62e28b8fb665f8196ca7547  ./dist/fs-utils.js.map
0e3296439edbc8f63c8be98cfb7d72c2  ./dist/types/personality.types.d.ts.map
0ee5239efdef80f0793b230a47207b67  ./dist/nexus-runtime.js
0ef7124a9af46a492cdbb37128af46fb  ./dist/consciousness/problem-decomposition.json
108de47b87aba11ba4d61768c459394d  ./dist/loaders/PersonalityRegistryLoader.js.map
111ca59402e761028aff311c9834092c  ./profiles/pulse.json
12bf255d692443b52533aced71fe8a13  ./dist/types.d.ts.map
14a33e488a3979f52c312daa1fd98d43  ./profiles/daedalus.json
14e840c8d750981f4bb025413c4ab14d  ./dist/nexus-runtime.d.ts.map
14ec8f9ca98a26e93db1a03c80f29af2  ./dist/types/personality.types.js.map
15a0296b917c242ddf26afff40da94d6  ./docs/18_PERSONALITIES_INSTALLATION_COMPLETE.md
16657dc4e56644991805c610821e6681  ./profiles/artdirector.json
19e9ac37ba1e45e5c11170f3dd361824  ./dist/Hunter.audit.d.ts.map
1aefb9e726d3c16c61917e0fedc36788  ./dist/response-generators/ResponseGeneratorFactory.d.ts.map
1c8ae08edd354ae59084f79215443f12  ./docs/NEXUS_PHASE3_COMPLETE.md
1df4b5752849720fe0cc93062f4f9457  ./dist/response-generators/ResponseGenerator.interface.d.ts
1ea2b738235b6ae68f147be8516cb1fe  ./dist/nexus-integration.js
2044b2d9e70d6b318f853b69ea411ed3  ./dist/guardian-orchestrator.d.ts.map
20e48e30717ecb7517bc2d32802cad21  ./profiles/integrationmaestro.json
20f0b8db09ef32cedea65385e692f5a1  ./dist/response-generators/ResponseGeneratorFactory.js
22a0c9c5cdf9937fe04564fc4b0e2863  ./dist/demo-personality-loader.js
24e66dd1cc38b3cd15c6e2681a2778a3  ./dist/validation/personality-schema.d.ts.map
26914bfa2958775b165a216e7ee62230  ./dist/NEXUS.integration.js
26d3c4ea6b53b9c134193caaf4597b2f  ./dist/demo-personality-loader.d.ts.map
27307d7f9413751ef4e41526fcadf8b4  ./dist/guardian-orchestrator.d.ts
28ac588fcd885d4b94bf01483a5aaa7f  ./dist/nexus-runtime.d.ts
2b0c713449fdcd3ce8f14aa6db1f90db  ./dist/systemic-scanner.js.map
2b91154838d90314296775554fd190b1  ./dist/response-generators/ResponseGeneratorFactory.js.map
2e72d105366abab1d516ff8dbf565f0b  ./profiles/styleforge.json
31bad4852404cd4fca601a5db49a06de  ./dist/Hunter.policy.js
31f37d7bd5a01d7cf7506ad522ff663b  ./dist/NEXUS.engine.d.ts.map
32742d9dd85e59316dab13096708826b  ./profiles/contextweaver.json
329f77c988bd62b3418aa97979a925b4  ./dist/response-generators/ResponseGenerator.interface.js.map
32cb141e3c66b92889dafd2d0f70d396  ./profiles/atlas-geo.json
32f0f84a23f64cfd583f52f05786031d  ./dist/run-hunter-audit.d.ts
3329dcf7c3e9264ff21737700588df2b  ./profiles/pythonista.json
33ec28d650e72201f6564c31012d1764  ./dist/Hunter.auditAgent.d.ts.map
34be01160e649d313d6099f76315bce1  ./dist/loaders/PersonalityRegistryLoader.d.ts
3523ad247f1a9fdf31b880dbce579ef1  ./docs/NEXUS_INITIAL_FINDINGS.md
35f999f8502cabc62921ff8412f24b35  ./dist/NEXUS.engine.js
36662cca10c573acfd447218fde9ae08  ./dist/response-generators/HunterResponseGenerator.d.ts.map
390fcc1d2d2694d791069946b4f3ee60  ./dist/NEXUS.engine.d.ts
395ea6c8db1f2b4bc6042a8dcc3bc562  ./dist/nexus-bridge.js.map
3987dadc6ffe900b233c1e3f887c723e  ./dist/types/personality.types.js
3cd49914c210370fcd377295d5898806  ./dist/types.js
3ff47cddc85cef1a0dfabb39e9f0d38d  ./dist/personality-architect-integration-test.d.ts
4028087abf549aff86ad23e20f1ee2fe  ./profiles/promptcrafter.json
40a27189acbcf9bb27f0087de19a86e3  ./dist/Hunter.audit.js.map
40e23b20dd9ce11945c1c15954e092cf  ./profiles/promptsmith.json
4100cc591462833ed24630b5f2e61bd2  ./dist/response-generators/HunterResponseGenerator.js.map
41b01be938c8e0bae0e8718af03bc18e  ./dist/demo-personality-loader.d.ts
43eddbb161425c8633ffd6e2d6962fdd  ./dist/NEXUS.engine.v2.d.ts
4721d9e4acc4d19456ee985ca39b78fc  ./dist/run-hunter-audit.d.ts.map
486aa789ec167b1e115eadf059b0c325  ./dist/Hunter.auditAgent.d.ts
49998e7c5fc238c594b37dfbf2c86379  ./INSTALL.md
4a4cfa5c8a1410cae7ef8e67289083d3  ./dist/nexus-bridge.js
4b7f5d7f2297de321c193be83ff4b0c9  ./profiles/forge.json
51a6a6626a0a66051a30ef8d70690523  ./dist/personality-architect-integration-test.js.map
523d7c12cdfeb34afc41129a0f19219a  ./docs/NEXUS_BRAIN_INVESTIGATION.md
5260d8643bafd83a3672fb7b32b34f83  ./dist/response-generators/ResponseGenerator.interface.d.ts.map
531282cb1d4f05931b97b11e26ecd49e  ./profiles/scribe.json
542b62afd49682ee109de6915eb2efc9  ./src/validation/personality-schema.ts
547958c8b24006759ff78605b6ea3c01  ./dist/guardian-orchestrator.js
5529760a59968e409d260ec90656ca61  ./dist/nexus-runtime.v2.js.map
560e19a206b6cc23f88830c2bd3344e2  ./profiles/performancehawk.json
5aae197c8777cce454924cfae1860d5f  ./dist/personality-architect-integration-test.d.ts.map
5d29da9e0354b77b999b8f2c7f0aaf82  ./dist/response-generators/ResponseGenerator.interface.js
5d6dc13aa47118292b008e2fd254e2d8  ./profiles/finetuner.json
5e78cd40b6de7ae59fd5e25616aceff3  ./dist/validation/personality-schema.js
6331eec909a3497d87b6846ec33fafff  ./profiles/codex-liaison.json
6467c4d6ca191ca2e3a169e88c2c9cf4  ./profiles/nexus-api.json
64f631a24a71fede8bfff75d87a47664  ./profiles/flash.json
65e279311b3998962ef02615b673179a  ./dist/Hunter.auditAgent.js
661e4a73f8afd92ba2d453d4691706bc  ./dist/nexus-integration.js.map
6631956e81ff5c2882d2f8401b4d35f1  ./dist/consciousness/systems-thinking.json
66ca9313b23f323e5124b6ccd296065a  ./dist/NEXUS.integration.d.ts
67edd90d6b894f7257dcb839fd07011a  ./profiles/photorealist.json
6800fcbcb74de7fe28a7ae7473a041b7  ./dist/fs-utils.js
682e52ca942daf80bfe565e271c57ed4  ./dist/response-generators/HunterResponseGenerator.d.ts
6bb15526734c2dc006c0233c8c52cf40  ./profiles/chorus.json
6c235c4989bee997d84c0c6dd0a87032  ./profiles/symphony.json
6de654addc420173951ff7104ca0974b  ./dist/nexus-trait-bridge.d.ts.map
6de895152d3f6b12a890e8a324cec8e6  ./profiles/chromatic.json
70008cf4095252bb665c8b501f6c9a61  ./dist/validation/personality-schema.d.ts
713257fca6fc295991fdea4adfe6c163  ./docs/NEXUS_PHASE2_COMPLETE.md
740a873cde32c352eba322eaaf9cb984  ./profiles/localize.json
747e92b9212c1f0e121bdaaaffeba06c  ./tsconfig.json
75748263bb83001d47c6650f1d0d2139  ./dist/Hunter.auditAgent.js.map
77f5bc73adfa4e2f116a1f06b07ba057  ./dist/response-generators/ResponseGeneratorFactory.d.ts
7894d51b04dc0d6cd363458ff1bacc51  ./dist/response-generators/HunterResponseGenerator.js
7da3d54830f6a0361616d7d8c00c08ef  ./dist/NEXUS.engine.js.map
7e3088eb2d2c8262f418aecae2c6db82  ./dist/nexus-runtime.v2.js
7f8f2c95d970534ee603d38c166dfaff  ./src/loaders/PersonalityRegistryLoader.ts
7fc0eeef65c57f8e0361840b0786b437  ./dist/architect-designs-hunter.d.ts
847a4ba89fcaaab4fdfa06240bdb85f4  ./profiles/narrative.json
863ed6baed65b544d78007aff0ddc08f  ./profiles/chainarchitect.json
863fba8dd7f16411dec366a6315ee9ce  ./dist/Hunter.policy.d.ts.map
8764f7d1703cfdb98997a64ec9eb56c6  ./dist/Hunter.audit.js
899cd92c7b4b2aa0212f3f2510b25a53  ./dist/NEXUS.integration.d.ts.map
8a2aa855131bb01182aa35e82fd955a4  ./dist/Hunter.audit.d.ts
8c65fe514d55e4e04aa2449b9594ecce  ./dist/validation/personality-schema.js.map
8c831e104dafcb25fb54033b9447be3e  ./profiles/personality-architect.json
8e7f64707bd4b1c8ad78f2bd8cdc178a  ./dist/loaders/PersonalityRegistryLoader.js
91851e21c10b52d454ab234952a1935c  ./profiles/tokenmaster.json
92411b76d7678ae86a53e803d3d1fc3e  ./profiles/ethicsguard.json
93388b2f47828895d224c48e4772a0a8  ./dist/Hunter.policy.d.ts
94af82c3b1e8a46461019e0c832cec5b  ./profiles/quantumlogic.json
97ea153dda65475bdf2cb746848d1b10  ./dist/fs-utils.d.ts
987af6d5f8d21ee092ec3f597d80833b  ./profiles/muse.json
9a9f0ec0d8ef2c44f4ef2dead1ffa84f  ./dist/response-generators/DaedalusResponseGenerator.d.ts
9bf0bbd0c61e58d9e5ba4edf9eeee01f  ./dist/fs-utils.d.ts.map
9d21228f86df7ddc58c190ab39bfe0b3  ./docs/NEXUS_EXECUTIVE_SUMMARY.md
a0891ace2950907d74b805b201e6d0c6  ./profiles/aria.json
a0e20b9e0608a83afc0ff02e082b3c43  ./dist/response-generators/DaedalusResponseGenerator.js.map
a316d0e934af2f82295120d6be841f7f  ./dist/nexus-runtime.js.map
a3e9c20e63b65eda4f1a0be8b7cb1676  ./package.json
a51d0262a2a9c798a6432c8941460322  ./dist/NEXUS.engine.v2.d.ts.map
a5b4f8b0752681077561c7cede2921e0  ./dist/consciousness/breakthrough-moments.json
a7ad25e22f2f2c8a2d81bd4129e16303  ./dist/nexus-integration.d.ts.map
a81c67fd594be4d38a38d30ce0aa0f9c  ./profiles/wordsmith.json
a858269e161be4d0b1e3318bb9a46021  ./dist/response-generators/DaedalusResponseGenerator.d.ts.map
a914f352e6c4943959e939930bbb3b22  ./docs/README.md
a9aadd6dea8fa6d00159a7ff9d8e7dea  ./profiles/datawhisperer.json
ab25bf54dc95fe2d4ec17cb3bccf436c  ./src/NEXUS.engine.v2.ts
ac18ac26631861f450705e3b5dd39b9a  ./docs/COMPREHENSIVE_REPORT.md
ad3c20e4112c0c7d6128c9c709e15b83  ./dist/nexus-runtime.v2.d.ts
ad6e4e4ba6f9b244a7872ed7ae9a3efd  ./dist/types.js.map
adeee293e89b8225127ceac3f4b7575d  ./dist/nexus-integration.d.ts
aea3eabb64c61238c0e7ddd2ad50554d  ./dist/personality-architect-integration-test.js
b069922ec56d090315094b3b960dffc6  ./profiles/sage.json
b0ae0612da6680a62c5d864e2d4a8909  ./dist/run-hunter-audit.js.map
b11b16633bb5b6b21b7eb881679e5ec5  ./dist/NEXUS.engine.v2.js
b3148984b0439cc0fe48fdb7f31c4c2e  ./dist/consciousness/enhancement-history.json
b36a31603f99b46d9187aa5129708e83  ./src/types/personality.types.ts
b61213798607b2bddbdb6199a29895c2  ./dist/consciousness/workflow-efficiency.json
b6bfcacbcc84c5172a8f1e76368763b1  ./docs/MANIFEST.md
b7fb7c3d631146ea2e3670210b541f30  ./dist/types/personality.types.d.ts
ba78a34ea60ec225443e389e2ed23455  ./profiles/property-sage.json
bafb212ed9ba045c12fd40a512417b88  ./dist/architect-designs-hunter.js.map
bc7e33353d2d8a562d22d46fc6ecbfec  ./dist/nexus-bridge.d.ts
bf28d07ac62abc04e9f8f0a3108bee5a  ./docs/INDEX.md
c052e512dfa92a6f645eba5bc86b1bdc  ./dist/loaders/PersonalityRegistryLoader.d.ts.map
c4e67bcd3f7c1a571b0940475cb21e53  ./src/nexus-runtime.v2.ts
c5d2d68b439dbd44a309a4a4c3fd1b1a  ./profiles/visionary.json
c7eae2eb2911bf31c147b04e9e5a9996  ./README.md
c9661d51673f1186d38d4be2885b5a8e  ./dist/nexus-bridge.d.ts.map
cbfb1b941d5be5e7e88077f5c12009ae  ./profiles/manifest.json
ce82ac95db8544631ac87c64ef134555  ./profiles/route-master.json
d09fe2dd25e907a95182610d06b2c671  ./dist/NEXUS.engine.v2.js.map
d0be09ce25e8a6758f67e81bd136454b  ./profiles/cipher.json
d38d633dc68688b24e3e09c380a81eb3  ./dist/nexus-runtime.v2.d.ts.map
d41d8cd98f00b204e9800998ecf8427e  ./MANIFEST.md
d44b1cb45d6c1176ca7ea3f61f7e7eff  ./dist/systemic-scanner.js
d58f0988dc2b5f24caf82e241dd9a8ab  ./dist/response-generators/DaedalusResponseGenerator.js
d64e1f9507bd6a2b69729db8348aea09  ./dist/NEXUS.integration.js.map
d6e9bc7c3c3e9701b2b73d640c964327  ./dist/architect-designs-hunter.js
da24d76f7be24406391122b281b28208  ./docs/NEXUS_PHASE1_COMPLETE.md
dca0a9f715b9cd4856a3b64913e0ceed  ./dist/Hunter.policy.js.map
df0540de33a62868f53d3fa5a84bcb29  ./profiles/visualarchitect.json
e2e91f075840f67a189f5541b7c5badb  ./dist/consciousness/pattern-evolution-engine.json
e371f712eef91f7d5bf7a3a4a744307a  ./dist/nexus-trait-bridge.js
e48d314901979ee4f37d868f9d8cf9fa  ./verify-circuit-breaker.mjs
e97ab60bd0264ec934e948efa3916d53  ./docs/ENHANCEMENT_HISTORY_STATUS.md
e9b5d880864630f78ed537d564b5cf01  ./dist/demo-personality-loader.js.map
e9e141ff56aa8c79100e6a34ea0e7779  ./dist/types.d.ts
eb7af6a27804e1a8d92fec78d9ade171  ./docs/NEXUS2_README.md
ed27937f0044681e9e3e5e97a4c8bc6e  ./consciousness/enhancement-history.json
ef02b173a124cfa50a837bfab2de68d9  ./profiles/hunter.json
f0b5e5b94e84e4d6db30e6efa0c6d7ed  ./dist/nexus-trait-bridge.d.ts
f60bd23179c678c1d89076ea1a0fac5b  ./dist/architect-designs-hunter.d.ts.map
f6afa5eb5125fd474eb81aeb7dca0738  ./profiles/touch.json
f9ac833fcf4ca76bd946931fa9099a04  ./dist/nexus-trait-bridge.js.map
fd69fc8e23170b5eb47c6fa86f49b549  ./dist/systemic-scanner.d.ts.map
feb71b374e9e5327939d2af95275d1ee  ./dist/run-hunter-audit.js
febbfd0308d7b4c85c6204084fb14540  ./profiles/atlas.json
```
