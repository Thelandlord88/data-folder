# NEXUS v3 Installation Guide

## Prerequisites

- Node.js 18+ 
- npm 9+

## Quick Start

```bash
# 1. Extract the package
tar -xzf nexus-v3-complete.tar.gz
cd nexus-v3-complete

# 2. Install dependencies
npm install

# 3. Build TypeScript (if not pre-compiled)
npm run build

# 4. Start NEXUS
npm start
```

## What's Included

- ✅ 45 Personality Profiles (JSON)
- ✅ TypeScript Source Files
- ✅ Compiled JavaScript Runtime
- ✅ Trait Composition Engine
- ✅ Circuit Breaker Pattern
- ✅ Rate Limiting
- ✅ Response Caching
- ✅ Input Validation
- ✅ Error Handling

## Verify Installation

```bash
# Check status
curl http://localhost:8080/status

# Test enhancement
curl -X POST http://localhost:8080/enhance \
  -H "Content-Type: application/json" \
  -d '{"request": "test", "mode": "AUTO"}'
```

## Features

- **AUTO Mode**: Automatically selects optimal personality
- **COMPOSE Mode**: Multi-personality trait composition
- **45 Personalities**: From Cipher (security) to Muse (creativity)
- **Rate Limiting**: 30 requests/min per IP
- **Caching**: 5-minute TTL, 100 response cache
- **Type Safety**: Full TypeScript implementation

## Endpoints

- `GET /status` - System health and statistics
- `POST /enhance` - Main personality enhancement
- `POST /breakthrough` - Report breakthrough moments
- `WebSocket /ws` - Live updates

## Configuration

Edit `src/nexus-runtime.v2.ts` to adjust:
- Rate limits (default: 30/min)
- Cache size (default: 100)
- Cache TTL (default: 5 minutes)
- Server port (default: 8080)

## Troubleshooting

**Port already in use:**
```bash
lsof -i :8080
# Kill the process or change port
```

**Missing dependencies:**
```bash
npm install
```

**Compilation errors:**
```bash
npm run build
```

## Support

For issues, check the docs/ directory or review the source code comments.
